window.addEventListener('DOMContentLoaded', () => {
  console.log("Portfolio loaded successfully!");
});
